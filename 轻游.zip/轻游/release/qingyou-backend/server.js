const http = require('http')
const https = require('https')
const fs = require('fs')
const path = require('path')
const crypto = require('crypto')

const PORT = Number(process.env.PORT || 3100)
const ROOT = __dirname
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data')
const DATA_FILE = path.join(DATA_DIR, 'categories.json')
const TRIPS_FILE = path.join(DATA_DIR, 'trips.json')
const AUTH_FILE = path.join(DATA_DIR, 'auth.json')
const PUBLIC_DIR = path.join(ROOT, 'public')
const UPLOAD_DIR = path.join(PUBLIC_DIR, 'uploads')
const ASSETS_DIR = path.join(PUBLIC_DIR, 'assets')
const MAX_BODY = 4 * 1024 * 1024
const SESSION_TTL = 30 * 24 * 60 * 60 * 1000
const INVITE_TTL = 7 * 24 * 60 * 60 * 1000

fs.mkdirSync(UPLOAD_DIR, { recursive: true })
fs.mkdirSync(ASSETS_DIR, { recursive: true })
fs.mkdirSync(DATA_DIR, { recursive: true })
for (const source of ['dessert.png', 'snack.png', 'drink.png']) {
  const input = path.join(ASSETS_DIR, source)
  const output = path.join(UPLOAD_DIR, source)
  if (fs.existsSync(input) && !fs.existsSync(output)) fs.copyFileSync(input, output)
}

function json(res, status, value) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': process.env.CORS_ORIGIN || '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization'
  })
  res.end(JSON.stringify(value))
}
function adminAuthorized(req) {
  const expected = String(process.env.ADMIN_TOKEN || '')
  if (!expected) return true
  const supplied = String(req.headers['x-admin-token'] || '')
  if (!supplied || supplied.length !== expected.length) return false
  return crypto.timingSafeEqual(Buffer.from(supplied), Buffer.from(expected))
}
function publicOrigin(req, url) {
  // 线上固定域名兜底：无论由 PM2/宝塔/手动哪种方式启动都能返回 https 地址；设置环境变量 PUBLIC_BASE_URL 仍可覆盖。
  return String(process.env.PUBLIC_BASE_URL || 'https://api.yycs.cloud').replace(/\/$/, '')
}
function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')) } catch { return fallback }
}
function writeJson(file, value) { fs.writeFileSync(file, JSON.stringify(value, null, 2)) }
function readCategories() { return readJson(DATA_FILE, []).sort((a, b) => a.sort - b.sort) }
function writeCategories(list) { writeJson(DATA_FILE, list.sort((a, b) => a.sort - b.sort)) }
function readTrips() { return readJson(TRIPS_FILE, {}) }
function writeTrips(value) { writeJson(TRIPS_FILE, value) }
function readAuth() { return readJson(AUTH_FILE, { users: {}, sessions: {}, invites: {} }) }
function writeAuth(value) { writeJson(AUTH_FILE, value) }
function requestBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = []
    req.on('data', chunk => {
      size += chunk.length
      if (size > MAX_BODY) reject(new Error('请求内容过大'))
      else chunks.push(chunk)
    })
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString() || '{}')) }
      catch { reject(new Error('JSON 格式错误')) }
    })
    req.on('error', reject)
  })
}
function serve(res, file) {
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) return false
  const ext = path.extname(file).toLowerCase()
  const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml' }
  const noCache = ['.html', '.css', '.js'].includes(ext)
  res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream', 'Cache-Control': noCache ? 'no-cache' : 'public,max-age=86400' })
  fs.createReadStream(file).pipe(res)
  return true
}
function token(size = 24) { return crypto.randomBytes(size).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '') }
function userId(openid) { return `user-${crypto.createHash('sha256').update(openid).digest('hex').slice(0, 20)}` }
function cleanProfile(profile = {}) {
  return {
    name: String(profile.name || profile.nickName || '微信用户').trim().slice(0, 40) || '微信用户',
    avatarUrl: String(profile.avatarUrl || '/assets/avatar-me.png').slice(0, 500)
  }
}
function getCurrentUser(req, auth) {
  const header = String(req.headers.authorization || '')
  const sessionToken = header.startsWith('Bearer ') ? header.slice(7) : ''
  const session = auth.sessions[sessionToken]
  if (!session || session.expiresAt < Date.now() || !auth.users[session.userId]) return null
  return auth.users[session.userId]
}
// 同一微信账号此前若以“设备号身份”（dev:xxx，未配置 WECHAT_APPID/SECRET 时的兜底）登录过，
// 拿到真实 openid 后把其行程成员关系、邀请与资料合并到真实身份，避免多端登录被拆成多个成员。
function mergeDevIdentity(auth, devId, realUserId) {
  const dev = auth.users[devId]
  if (!dev) return
  const real = auth.users[realUserId]
  if (real && (real.name === '微信用户' || !real.name) && dev.name && dev.name !== '微信用户') {
    real.name = dev.name
    if (dev.avatarUrl && (!real.avatarUrl || real.avatarUrl === '/assets/avatar-me.png')) real.avatarUrl = dev.avatarUrl
  }
  delete auth.users[devId]
  const trips = readTrips()
  let changed = false
  Object.entries(trips).forEach(([tripId, trip]) => {
    let touched = false
    if (trip.ownerId === devId) { trip.ownerId = realUserId; touched = true }
    if (Array.isArray(trip.memberIds) && trip.memberIds.includes(devId)) {
      trip.memberIds = [...new Set(trip.memberIds.map(value => value === devId ? realUserId : value))]
      touched = true
    }
    if (Array.isArray(trip.members) && trip.members.some(member => member && member.id === devId)) {
      trip.members = trip.members.filter(member => !member || member.id !== devId)
      touched = true
    }
    if (touched) { trips[tripId] = trip; changed = true }
  })
  if (changed) writeTrips(trips)
  Object.keys(auth.invites || {}).forEach(key => {
    if (auth.invites[key].inviterId === devId) { auth.invites[key].inviterId = realUserId; changed = true }
  })
}
function legacyMembers(trip) { return Array.isArray(trip.members) ? trip.members.filter(item => item && item.id) : [] }
function ensureMembership(trip, currentUser) {
  const memberIds = Array.isArray(trip.memberIds) ? trip.memberIds : []
  return Boolean(currentUser && (trip.ownerId === currentUser.id || memberIds.includes(currentUser.id)))
}
function serializeTrip(id, trip, auth) {
  const ids = [...new Set([trip.ownerId, ...(trip.memberIds || [])].filter(Boolean))]
  const users = ids.map(value => auth.users[value]).filter(Boolean).map(user => ({ id: user.id, name: user.name, avatarUrl: user.avatarUrl }))
  const members = users.length ? users : legacyMembers(trip)
  const result = { ...trip, id, tripId: id, members }
  delete result.memberIds
  return result
}
function httpsJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, response => {
      const chunks = []
      response.on('data', chunk => chunks.push(chunk))
      response.on('end', () => {
        try { resolve({ statusCode: response.statusCode || 0, value: JSON.parse(Buffer.concat(chunks).toString() || '{}') }) }
        catch (error) { reject(error) }
      })
    }).on('error', reject)
  })
}
async function exchangeCode(code) {
  const appid = process.env.WECHAT_APPID
  const secret = process.env.WECHAT_SECRET
  if (!appid || !secret || !code) return null
  try {
    const url = new URL('https://api.weixin.qq.com/sns/jscode2session')
    url.searchParams.set('appid', appid)
    url.searchParams.set('secret', secret)
    url.searchParams.set('js_code', code)
    url.searchParams.set('grant_type', 'authorization_code')
    const response = await httpsJson(url)
    const value = response.value
    if (response.statusCode < 200 || response.statusCode >= 300 || value.errcode || !value.openid) throw new Error(value.errmsg || '微信登录失败')
    return value.openid
  } catch {
    // AppSecret 配错或凭证无效时退回设备号身份，避免登录接口 500 导致小程序整体不可用
    return null
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`)
  if (req.method === 'OPTIONS') return json(res, 204, {})
  try {
    if (url.pathname === '/health' && req.method === 'GET') return json(res, 200, { ok: true })
    if (url.pathname === '/auth/login' && req.method === 'POST') {
      const value = await requestBody(req)
      const wxOpenid = await exchangeCode(value.code)
      const openid = wxOpenid || `dev:${String(value.devKey || '').trim()}`
      if (openid === 'dev:') return json(res, 400, { message: '缺少登录凭证' })
      const auth = readAuth(), id = userId(openid), prev = auth.users[id] || {}
      const profile = cleanProfile(value.profile)
      // 客户端还没填真实昵称/头像时不覆盖服务端已有资料（可能在其他设备填写过）
      const next = { ...prev, id, openid, updatedAt: Date.now(), createdAt: prev.createdAt || Date.now() }
      if (profile.name !== '微信用户' || !prev.name) next.name = profile.name
      if (profile.avatarUrl && profile.avatarUrl !== '/assets/avatar-me.png') next.avatarUrl = profile.avatarUrl
      else if (!prev.avatarUrl) next.avatarUrl = profile.avatarUrl
      auth.users[id] = next
      if (wxOpenid && value.devKey) {
        const devId = userId(`dev:${String(value.devKey).trim()}`)
        if (devId !== id && auth.users[devId]) mergeDevIdentity(auth, devId, id)
      }
      const sessionToken = token(32)
      auth.sessions[sessionToken] = { userId: id, expiresAt: Date.now() + SESSION_TTL }
      Object.keys(auth.sessions).forEach(key => { if (auth.sessions[key].expiresAt < Date.now()) delete auth.sessions[key] })
      writeAuth(auth)
      return json(res, 200, { token: sessionToken, user: { id, name: auth.users[id].name, avatarUrl: auth.users[id].avatarUrl } })
    }

    if (url.pathname === '/categories' && req.method === 'GET') {
      const origin = publicOrigin(req, url)
      return json(res, 200, { list: readCategories().filter(item => item.enabled !== false).map(item => ({ ...item, iconUrl: item.iconUrl.startsWith('http') ? item.iconUrl : origin + item.iconUrl })) })
    }
    if (url.pathname.startsWith('/admin/') && !adminAuthorized(req)) return json(res, 401, { message: '后台管理口令错误' })
    if (url.pathname === '/admin/categories' && req.method === 'GET') return json(res, 200, { list: readCategories() })
    if (url.pathname === '/admin/categories' && req.method === 'POST') {
      const value = await requestBody(req), list = readCategories()
      const item = { id: crypto.randomUUID(), name: String(value.name || '').trim(), iconUrl: value.iconUrl || '', sort: Number(value.sort || (list.length + 1) * 10), enabled: value.enabled !== false }
      if (!item.name || !item.iconUrl) return json(res, 400, { message: '名称和图片不能为空' })
      list.push(item); writeCategories(list); return json(res, 201, item)
    }
    const categoryMatch = url.pathname.match(/^\/admin\/categories\/([^/]+)$/)
    if (categoryMatch && req.method === 'PUT') {
      const value = await requestBody(req), list = readCategories(), index = list.findIndex(item => item.id === categoryMatch[1])
      if (index < 0) return json(res, 404, { message: '分类不存在' })
      list[index] = { ...list[index], name: String(value.name || list[index].name).trim(), iconUrl: value.iconUrl || list[index].iconUrl, sort: Number(value.sort ?? list[index].sort), enabled: value.enabled !== false }
      writeCategories(list); return json(res, 200, list[index])
    }
    if (categoryMatch && req.method === 'DELETE') {
      writeCategories(readCategories().filter(item => item.id !== categoryMatch[1]))
      return json(res, 200, { ok: true })
    }
    if (url.pathname === '/admin/categories/reorder' && req.method === 'POST') {
      const value = await requestBody(req), list = readCategories(), order = Array.isArray(value.ids) ? value.ids : []
      order.forEach((id, index) => { const item = list.find(entry => entry.id === id); if (item) item.sort = (index + 1) * 10 })
      writeCategories(list); return json(res, 200, { list: readCategories() })
    }
    if (url.pathname === '/admin/upload' && req.method === 'POST') {
      const value = await requestBody(req), match = String(value.dataUrl || '').match(/^data:image\/(png|jpeg|webp|svg\+xml);base64,(.+)$/)
      if (!match) return json(res, 400, { message: '仅支持 PNG、JPG、WebP、SVG' })
      const ext = match[1] === 'jpeg' ? 'jpg' : match[1] === 'svg+xml' ? 'svg' : match[1]
      const name = `${Date.now()}-${crypto.randomBytes(4).toString('hex')}.${ext}`
      fs.writeFileSync(path.join(UPLOAD_DIR, name), Buffer.from(match[2], 'base64'))
      return json(res, 201, { iconUrl: `/uploads/${name}` })
    }

    if (url.pathname === '/admin/trips' && req.method === 'GET') {
      const trips = readTrips(), auth = readAuth()
      const list = Object.entries(trips).map(([id, trip]) => serializeTrip(id, trip, auth)).sort((a, b) => String(a.tripName).localeCompare(String(b.tripName), 'zh-CN'))
      return json(res, 200, { list })
    }
    const adminMemberMatch = url.pathname.match(/^\/admin\/trips\/([^/]+)\/members\/([^/]+)$/)
    if (adminMemberMatch && req.method === 'DELETE') {
      const trips = readTrips(), id = adminMemberMatch[1], memberId = adminMemberMatch[2], trip = trips[id]
      if (!trip) return json(res, 404, { message: '行程不存在' })
      if (trip.ownerId === memberId) return json(res, 400, { message: '不能移出行程创建者' })
      trip.memberIds = (trip.memberIds || []).filter(value => value !== memberId)
      trip.members = legacyMembers(trip).filter(value => String(value.id) !== memberId)
      trips[id] = trip; writeTrips(trips); return json(res, 200, { ok: true })
    }

    const auth = readAuth(), currentUser = getCurrentUser(req, auth)
    if (url.pathname === '/upload' && req.method === 'POST') {
      if (!currentUser) return json(res, 401, { message: '请先登录' })
      const value = await requestBody(req), match = String(value.dataUrl || '').match(/^data:image\/(png|jpeg|webp);base64,(.+)$/)
      if (!match) return json(res, 400, { message: '仅支持 PNG、JPG、WebP' })
      const raw = Buffer.from(match[2], 'base64')
      if (!raw.length) return json(res, 400, { message: '图片数据无效' })
      if (raw.length > 300 * 1024) return json(res, 413, { message: '图片过大，请压缩后再试' })
      const ext = match[1] === 'jpeg' ? 'jpg' : match[1]
      const name = `${Date.now()}-${crypto.randomBytes(4).toString('hex')}.${ext}`
      fs.writeFileSync(path.join(UPLOAD_DIR, name), raw)
      return json(res, 201, { url: `/uploads/${name}` })
    }
    if (url.pathname === '/me/trips' && req.method === 'GET') {
      if (!currentUser) return json(res, 401, { message: '请先登录' })
      const trips = readTrips()
      const list = Object.entries(trips).filter(([, trip]) => ensureMembership(trip, currentUser)).map(([id, trip]) => serializeTrip(id, trip, auth))
      return json(res, 200, { list })
    }
    const tripMatch = url.pathname.match(/^\/trips\/([^/]+)$/)
    if (tripMatch && req.method === 'GET') {
      if (!currentUser) return json(res, 401, { message: '请先登录' })
      const trips = readTrips(), id = tripMatch[1], trip = trips[id]
      if (!trip) return json(res, 404, { message: '行程不存在' })
      if (!ensureMembership(trip, currentUser)) return json(res, 403, { message: '你不是该行程成员' })
      return json(res, 200, { data: serializeTrip(id, trip, auth) })
    }
    if (tripMatch && req.method === 'PUT') {
      if (!currentUser) return json(res, 401, { message: '请先登录' })
      const value = await requestBody(req), trips = readTrips(), id = tripMatch[1]
      let trip = trips[id]
      if (!trip) trip = { id, tripId: id, tripName: '暂无行程', records: [], budget: 0, trips: [], ownerId: currentUser.id, memberIds: [currentUser.id], createdAt: Date.now() }
      if (!trip.ownerId) { trip.ownerId = currentUser.id; trip.memberIds = [...new Set([currentUser.id, ...(trip.memberIds || [])])] }
      if (!ensureMembership(trip, currentUser)) return json(res, 403, { message: '你不是该行程成员' })
      const next = { ...trip, tripName: String(value.tripName || trip.tripName), records: Array.isArray(value.records) ? value.records : trip.records, budget: Number(value.budget ?? trip.budget), trips: Array.isArray(value.trips) ? value.trips : trip.trips, updatedAt: Date.now() }
      next.memberIds = [...new Set([next.ownerId, ...(next.memberIds || [])])]
      delete next.members
      trips[id] = next; writeTrips(trips)
      return json(res, 200, { data: serializeTrip(id, next, auth) })
    }
    const inviteCreateMatch = url.pathname.match(/^\/trips\/([^/]+)\/invites$/)
    if (inviteCreateMatch && req.method === 'POST') {
      if (!currentUser) return json(res, 401, { message: '请先登录' })
      const trips = readTrips(), id = inviteCreateMatch[1], trip = trips[id]
      if (!trip) return json(res, 404, { message: '行程不存在' })
      if (!ensureMembership(trip, currentUser)) return json(res, 403, { message: '你不是该行程成员' })
      const inviteToken = token(18)
      auth.invites[inviteToken] = { tripId: id, inviterId: currentUser.id, expiresAt: Date.now() + INVITE_TTL, createdAt: Date.now() }
      writeAuth(auth)
      return json(res, 201, { token: inviteToken, expiresAt: auth.invites[inviteToken].expiresAt })
    }
    const inviteJoinMatch = url.pathname.match(/^\/invites\/([^/]+)\/join$/)
    if (inviteJoinMatch && req.method === 'POST') {
      if (!currentUser) return json(res, 401, { message: '请先登录' })
      const invite = auth.invites[inviteJoinMatch[1]]
      if (!invite || invite.expiresAt < Date.now()) return json(res, 404, { message: '邀请已失效' })
      const trips = readTrips(), trip = trips[invite.tripId]
      if (!trip) return json(res, 404, { message: '行程不存在' })
      if (!trip.ownerId) trip.ownerId = invite.inviterId
      trip.memberIds = [...new Set([trip.ownerId, ...(trip.memberIds || []), currentUser.id])]
      delete trip.members
      trips[invite.tripId] = trip; writeTrips(trips)
      return json(res, 200, { data: serializeTrip(invite.tripId, trip, auth) })
    }

    if (url.pathname.startsWith('/uploads/')) {
      const file = path.resolve(PUBLIC_DIR, `.${url.pathname}`)
      if (!file.startsWith(UPLOAD_DIR)) return json(res, 403, { message: '禁止访问' })
      if (serve(res, file)) return
    }
    if (url.pathname.startsWith('/assets/')) {
      const file = path.resolve(ASSETS_DIR, `.${url.pathname.slice('/assets'.length)}`)
      if (!file.startsWith(ASSETS_DIR)) return json(res, 403, { message: '禁止访问' })
      if (serve(res, file)) return
    }
    const file = url.pathname === '/' ? path.join(PUBLIC_DIR, 'index.html') : path.resolve(PUBLIC_DIR, `.${url.pathname}`)
    if (file.startsWith(PUBLIC_DIR) && serve(res, file)) return
    return json(res, 404, { message: 'Not Found' })
  } catch (error) {
    return json(res, 500, { message: error.message || '服务器错误' })
  }
})

server.listen(PORT, '0.0.0.0', () => {
  console.log(`轻游后台：http://localhost:${PORT}`)
  if (!process.env.WECHAT_APPID || !process.env.WECHAT_SECRET) {
    console.warn('警告：未配置 WECHAT_APPID/WECHAT_SECRET，登录将退化为“设备号身份”，同一微信账号在 PC/手机会被视为不同用户')
  }
})
