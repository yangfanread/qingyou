const COLORS = ['#5b58e7', '#43d676', '#ff9f43', '#ff5e78', '#31b8d8', '#a36df0', '#f2c94c', '#5a8dee', '#8bc34a', '#ef6c9b']

function dateKey() {
  const date = new Date()
  const pad = value => String(value).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
}

function inPeriod(value, period) {
  const target = new Date(`${value}T00:00:00`)
  const now = new Date()
  now.setHours(0, 0, 0, 0)
  if (period === 0) return target.getFullYear() === now.getFullYear() && target.getMonth() === now.getMonth()
  if (period === 2) return value === dateKey()
  const day = now.getDay() || 7
  const start = new Date(now)
  start.setDate(now.getDate() - day + 1)
  const end = new Date(start)
  end.setDate(start.getDate() + 7)
  return target >= start && target < end
}

function money(value) {
  const number = Number(value) || 0
  return number >= 10000 ? `${(number / 10000).toFixed(2)}万` : number.toFixed(2)
}

function moneyParts(value) {
  const number = Number(value) || 0
  const compact = number >= 10000
  const shown = compact ? number / 10000 : number
  const parts = shown.toFixed(2).split('.')
  return {
    integer: parts[0],
    decimal: `.${parts[1]}`,
    unit: compact ? '万' : ''
  }
}

// 出场扫入进度 t∈[0,1]：各扇区角度整体乘以 t，从 12 点钟方向顺时针展开，未扫到部分透明。
function sweptStyle(categories, t) {
  let cursor = 0
  const stops = categories.map(item => {
    const start = cursor * t
    cursor += item.percent
    return `${item.color} ${start.toFixed(2)}% ${(cursor * t).toFixed(2)}%`
  })
  return `background:conic-gradient(${stops.join(',')},rgba(0,0,0,0) ${(cursor * t).toFixed(2)}% 100%)`
}

function buildStats(records, period) {
  const filtered = records.filter(item => item.date && inPeriod(item.date, period))
  const total = filtered.reduce((sum, item) => sum + Number(item.value || 0), 0)
  const categoryMap = {}
  filtered.forEach(item => {
    const id = item.categoryId || item.categoryName || 'other'
    if (!categoryMap[id]) categoryMap[id] = { id, name: item.categoryName || '其他', iconUrl: item.iconUrl || '/assets/dessert.png', value: 0, count: 0 }
    categoryMap[id].value += Number(item.value || 0)
    categoryMap[id].count += 1
  })
  const categories = Object.values(categoryMap).sort((a, b) => b.value - a.value).map((item, index) => ({
    ...item, color: COLORS[index % COLORS.length], percent: total ? item.value / total * 100 : 0,
    percentText: `${(total ? item.value / total * 100 : 0).toFixed(2)}%`, amountDisplay: moneyParts(item.value)
  }))
  let cursor = 0
  const stops = categories.map(item => {
    const start = cursor
    cursor += item.percent
    return `${item.color} ${start.toFixed(2)}% ${cursor.toFixed(2)}%`
  })
  const donutStyle = categories.length ? `background:conic-gradient(${stops.join(',')})` : 'background:#d9d8e2'
  const ranks = [...filtered].sort((a, b) => Number(b.value) - Number(a.value)).slice(0, 10).map((item, index) => ({
    ...item, rank: index + 1, medal: index < 3 ? `/assets/medal-${index + 1}.png` : '', amountDisplay: moneyParts(item.value)
  }))
  return { filtered, categories, ranks, totalDisplay: moneyParts(total), donutStyle, topLabels: categories.slice(0, 2) }
}

Page({
  data: { navHeight: 88, period: 0, periods: ['月', '周', '日'], categories: [], topLabels: [], ranks: [], totalDisplay: moneyParts(0), donutStyle: 'background:#d9d8e2', members: [{ id:'me', name:'我', avatarUrl:'/assets/avatar-me.png' }], sheetVisible: false, pageLeaving: false, navScrolled: false },
  onLoad() {
    const info = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync()
    const menu = wx.getMenuButtonBoundingClientRect()
    const stats = buildStats(getApp().globalData.records || [], this.data.period)
    this._donutFull = stats.donutStyle
    this.setData({ navHeight: menu.bottom + Math.max(menu.top - info.statusBarHeight, 4), members: getApp().globalData.members || this.data.members, ...stats })
  },
  onShow() {
    this.applyStats(getApp().globalData.records || [], this.data.period)
    this.replayDonut()
    this.refreshCategoryMetadata()
  },
  onUnload() {
    if (this.donutTimer) clearInterval(this.donutTimer)
  },
  refreshCategoryMetadata() {
    const app = getApp()
    if (!app.globalData.apiBase) return
    wx.request({
      url: `${app.globalData.apiBase}/categories`, data: { scene: 'expense' },
      success: response => {
        const list = Array.isArray(response.data) ? response.data : response.data && response.data.list
        if (!Array.isArray(list) || !list.length) return
        const byId = {}, byName = {}
        list.forEach(item => { if (!item) return; if (item.id) byId[String(item.id)] = item; if (item.name) byName[item.name] = item })
        const records = (app.globalData.records || []).map(record => {
          const category = byId[String(record.categoryId)] || byName[record.categoryName]
          return category ? { ...record, categoryId: category.id, categoryName: category.name, iconUrl: category.iconUrl } : record
        })
        const changed = records.some((record, index) => {
          const old = app.globalData.records[index] || {}
          return record.categoryId !== old.categoryId || record.categoryName !== old.categoryName || record.iconUrl !== old.iconUrl
        })
        if (!changed) return
        app.saveState({ records })
        this.applyStats(records, this.data.period)
        this.replayDonut()
      }
    })
  },
  onPageScroll(event) {
    const navScrolled = Number(event.scrollTop || 0) > 4
    if (navScrolled !== this.data.navScrolled) this.setData({ navScrolled })
  },
  applyStats(records, period) {
    const stats = buildStats(records, period)
    this._donutFull = stats.donutStyle
    this.setData(stats)
  },
  // 参考 AntV 基础环图出场：扇区从 12 点钟方向顺时针扫入，720ms 缓出。
  replayDonut() {
    if (this.donutTimer) { clearInterval(this.donutTimer); this.donutTimer = null }
    const categories = this.data.categories
    if (!categories.length) return this.setData({ donutStyle: 'background:#d9d8e2' })
    const duration = 720
    const startedAt = Date.now()
    this.donutTimer = setInterval(() => {
      const progress = Math.min((Date.now() - startedAt) / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      this.setData({ donutStyle: sweptStyle(categories, eased) })
      if (progress >= 1) {
        clearInterval(this.donutTimer)
        this.donutTimer = null
        this.setData({ donutStyle: this._donutFull })
      }
    }, 16)
  },
  choosePeriod(e) {
    const period = Number(e.currentTarget.dataset.index)
    this.setData({ period })
    this.applyStats(getApp().globalData.records || [], period)
    this.replayDonut()
  },
  goHome() {
    this.setData({ pageLeaving: true })
    setTimeout(() => wx.redirectTo({ url: '/pages/home/index' }), 180)
  },
  addRecord() {
    const app = getApp()
    app.getUserProfile().then(() => this.setData({ members: app.globalData.members, sheetVisible: true }))
  },
  closeSheet() { this.setData({ sheetVisible: false }) },
  confirmSheet(event) {
    const value = event.detail
    if (value.mode !== 'record') return this.setData({ sheetVisible: false })
    const record = { id: `record-${Date.now()}`, categoryId: value.category.id, categoryName: value.category.name, iconUrl: value.category.iconUrl, title: value.name, note: value.note, user: value.payer, date: value.date, time: value.time, value: Number(value.amount) }
    const records = [record, ...(getApp().globalData.records || [])]
    getApp().saveState({ records })
    getApp().pushTrip()
    this.setData({ sheetVisible: false })
    this.applyStats(records, this.data.period)
    this.replayDonut()
  }
})
