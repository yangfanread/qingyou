const records = []

function amountParts(value) {
  const number = Number(value) || 0
  const negative = number < 0
  const absolute = Math.abs(number)
  const compact = absolute >= 10000
  const shown = compact ? absolute / 10000 : absolute
  const parts = shown.toFixed(2).split('.')
  return {
    integer: `${negative ? '-' : ''}${parts[0]}`,
    decimal: `.${parts[1]}`,
    unit: compact ? '万' : ''
  }
}

function localDate() {
  const now = new Date()
  const pad = value => String(value).padStart(2, '0')
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`
}

function dateParts(date) {
  const value = new Date(`${date}T00:00:00`)
  const weekdays = ['日', '一', '二', '三', '四', '五', '六']
  return { label: `${value.getMonth() + 1}月${value.getDate()}日`, weekday: `周${weekdays[value.getDay()]}` }
}

function buildGroups(items) {
  const today = localDate()
  const map = {}
  items.forEach(item => {
    if (!map[item.date]) map[item.date] = []
    map[item.date].push(item)
  })
  return Object.keys(map).sort((a, b) => b.localeCompare(a)).map(date => {
    const parts = dateParts(date)
    const list = map[date]
    const total = list.reduce((sum, item) => sum + Number(item.value || 0), 0)
    return { date, dateLabel: parts.label, weekday: parts.weekday, isToday: date === today, records: list, count: list.length, totalDisplay: amountParts(total) }
  })
}

function totalsState(records, budget) {
  const normalizedRecords = records.map(item => ({ ...item, amountDisplay: amountParts(item.value) }))
  const total = normalizedRecords.reduce((sum, item) => sum + Number(item.value || 0), 0)
  const remaining = Number(budget || 0) - total
  return {
    records: normalizedRecords,
    groups: buildGroups(normalizedRecords),
    total: total.toFixed(2), totalDisplay: amountParts(total),
    groupTotal: total.toFixed(2),
    remaining: remaining.toFixed(2), remainingDisplay: amountParts(remaining),
    average: total.toFixed(2), averageDisplay: amountParts(total)
  }
}

Page({
  data: {
    navHeight: 88,
    records,
    groups: [],
    activeTab: 0,
    dateOpen: false,
    tripName: '暂无行程',
    tripLayerRendered: false,
    tripLayerVisible: false,
    tripManaging: false,
    journeyItems: [],
    activeTripId: '',
    tripDialogVisible: false,
    tripDialogMode: 'create',
    tripDialogValue: '',
    tripDialogFocus: false,
    tripEditId: '',
    total: '0.00',
    totalDisplay: amountParts(0),
    groupTotal: '0.00',
    budget: '0.00',
    budgetDisplay: amountParts(0),
    remaining: '0.00',
    remainingDisplay: amountParts(0),
    average: '0.00',
    averageDisplay: amountParts(0),
    currentDateLabel: dateParts(localDate()).label,
    currentDate: localDate(),
    recordsPinned: false,
    recordsPinnedTop: 0,
    members: [{ id: 'me', name: '我', avatarUrl: '/assets/avatar-me.png' }],
    memberId: '',
    userAvatarUrl: '',
    avatarHintVisible: false,
    swipedRecordId: '',
    editingRecord: null,
    sheetVisible: false,
    sheetMode: 'record',
    pageLeaving: false
    ,navScrolled: false
  },

  onShow() {
    const shared = getApp().globalData
    const groups = buildGroups(shared.records || [])
    this.setData({ pageLeaving: false, budget: Number(shared.budget || 0).toFixed(2), budgetDisplay: amountParts(shared.budget), members: shared.members || this.data.members, memberId: shared.memberId || this.data.memberId, tripName: shared.tripName || '暂无行程', ...totalsState(shared.records || [], shared.budget), currentDate: groups.length ? groups[0].date : localDate(), currentDateLabel: groups.length ? groups[0].dateLabel : dateParts(localDate()).label }, () => {
      setTimeout(() => this.measureRecordsPin(), 30)
    })
    if (shared.apiBase) getApp().syncTrip().then(data => {
      if (!data) return
      const groups = buildGroups(getApp().globalData.records || [])
      this.setData({ members: getApp().globalData.members, tripName: getApp().globalData.tripName, ...totalsState(getApp().globalData.records, getApp().globalData.budget), currentDate: groups.length ? groups[0].date : localDate(), currentDateLabel: groups.length ? groups[0].dateLabel : dateParts(localDate()).label }, () => {
        setTimeout(() => this.measureRecordsPin(), 30)
      })
      this.refreshCategoryMetadata()
    })
    this.refreshCategoryMetadata()
    this.prepareInvite()
    // 首次引导：头像未设置时，在成员区自己头像上方显示气泡；点头像直接拉起微信原生面板（用微信头像/相册/拍照），不做自制弹窗
    const app = getApp()
    Promise.resolve(app.authReady).then(() => {
      const avatarOk = app.globalData.userAvatarUrl && !/avatar-me/.test(app.globalData.userAvatarUrl)
      if (!avatarOk && !app.globalData.profilePrompted) this.setData({ avatarHintVisible: true })
    })
  },

  refreshCategoryMetadata() {
    const app = getApp()
    if (!app.globalData.apiBase) return
    wx.request({
      url: `${app.globalData.apiBase}/categories`,
      data: { scene: 'expense' },
      success: response => {
        const list = Array.isArray(response.data) ? response.data : response.data && response.data.list
        if (!Array.isArray(list) || !list.length) return
        const byId = {}
        const byName = {}
        list.forEach(item => {
          if (item && item.id) byId[String(item.id)] = item
          if (item && item.name) byName[item.name] = item
        })
        const records = (app.globalData.records || []).map(record => {
          const category = byId[String(record.categoryId)] || byName[record.categoryName]
          return category ? { ...record, categoryName: category.name, iconUrl: category.iconUrl } : record
        })
        const changed = records.some((record, index) => record.iconUrl !== (app.globalData.records[index] && app.globalData.records[index].iconUrl) || record.categoryName !== (app.globalData.records[index] && app.globalData.records[index].categoryName))
        if (!changed) return
        app.saveState({ records })
        this.setData({ ...totalsState(records, app.globalData.budget) })
      }
    })
  },

  buildJourneyItems() {
    const app = getApp()
    const myId = app.globalData.memberId
    return (app.globalData.journeys || []).map(item => ({
      id: item.id,
      name: item.name || '暂无行程',
      membersLabel: (item.members || []).map(member => {
        if (!member) return ''
        if (member.id === 'me' || member.id === myId) return '我'
        return member.name || ''
      }).filter(Boolean).join('、') || '我',
      active: item.id === app.globalData.activeTripId
    }))
  },

  applySharedState() {
    const shared = getApp().globalData
    const groups = buildGroups(shared.records || [])
    this.setData({
      tripName: shared.tripName || '暂无行程', members: shared.members || this.data.members,
      activeTripId: shared.activeTripId, journeyItems: this.buildJourneyItems(),
      budget: Number(shared.budget || 0).toFixed(2), budgetDisplay: amountParts(shared.budget),
      ...totalsState(shared.records || [], shared.budget),
      currentDate: groups.length ? groups[0].date : localDate(),
      currentDateLabel: groups.length ? groups[0].dateLabel : dateParts(localDate()).label
    }, () => { setTimeout(() => this.measureRecordsPin(), 30); this.prepareInvite() })
  },

  openTripSheet() {
    this.setData({ dateOpen: false, tripManaging: false, activeTripId: getApp().globalData.activeTripId, journeyItems: this.buildJourneyItems(), tripLayerRendered: true, tripLayerVisible: false })
    setTimeout(() => this.setData({ tripLayerVisible: true }), 20)
  },

  closeTripSheet() {
    this.setData({ tripLayerVisible: false, tripDialogVisible: false, tripDialogFocus: false })
    setTimeout(() => this.setData({ tripLayerRendered: false }), 340)
  },

  stopTripBubble() {},

  toggleTripManage() {
    this.setData({ tripManaging: !this.data.tripManaging })
  },

  selectTripItem(event) {
    if (this.data.tripManaging) return
    const id = event.currentTarget.dataset.id
    if (!id || id === getApp().globalData.activeTripId) return this.closeTripSheet()
    getApp().switchJourney(id)
    this.closeTripSheet()
    this.applySharedState()
  },

  openCreateTrip() {
    this.setData({ tripDialogMode: 'create', tripDialogValue: '', tripEditId: '', tripDialogVisible: true, tripDialogFocus: false }, () => {
      setTimeout(() => this.setData({ tripDialogFocus: true }), 240)
    })
  },

  editTripItem(event) {
    const id = event.currentTarget.dataset.id
    const journey = (getApp().globalData.journeys || []).find(item => item.id === id)
    if (!journey) return
    this.setData({ tripDialogMode: 'edit', tripDialogValue: journey.name || '', tripEditId: id, tripDialogVisible: true, tripDialogFocus: false }, () => {
      setTimeout(() => this.setData({ tripDialogFocus: true }), 240)
    })
  },

  cancelTripDialog() {
    this.setData({ tripDialogVisible: false, tripDialogFocus: false })
  },

  inputTripDialog(event) {
    this.setData({ tripDialogValue: event.detail.value })
  },

  confirmTripDialog() {
    const name = String(this.data.tripDialogValue || '').trim()
    if (!name) return wx.showToast({ title: '请输入行程名称', icon: 'none' })
    if (this.data.tripDialogMode === 'edit') {
      const journey = getApp().renameJourney(this.data.tripEditId, name)
      if (!journey) return wx.showToast({ title: '行程不存在', icon: 'none' })
      this.setData({ tripDialogVisible: false, tripDialogFocus: false })
      this.applySharedState()
      return
    }
    const journey = getApp().createJourney(name)
    this.setData({ tripDialogVisible: false, tripDialogFocus: false, tripLayerVisible: false })
    setTimeout(() => this.setData({ tripLayerRendered: false }), 340)
    this.applySharedState()
    wx.showToast({ title: '已创建行程', icon: 'none' })
  },

  removeTripItem(event) {
    const id = event.currentTarget.dataset.id
    const app = getApp()
    const journeys = app.globalData.journeys || []
    if (journeys.length <= 1) return wx.showToast({ title: '至少保留一个行程', icon: 'none' })
    const journey = journeys.find(item => item.id === id)
    if (!journey) return
    wx.showModal({
      title: '删除行程',
      content: `确定删除「${journey.name || '暂无行程'}」吗？删除后不可恢复。`,
      confirmText: '删除',
      confirmColor: '#ff7455',
      success: result => {
        if (!result.confirm) return
        app.deleteJourney(id)
        this.setData({ tripManaging: false })
        this.applySharedState()
      }
    })
  },

  editBudget() {
    this.setData({ sheetMode: 'budget', sheetVisible: true })
  },

  onLoad(options) {
    const system = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync()
    const menu = wx.getMenuButtonBoundingClientRect()
    const navHeight = menu.bottom + Math.max(menu.top - system.statusBarHeight, 4)
    const shared = getApp().globalData
    const groups = buildGroups(shared.records || [])
    this.setData({ navHeight, budget: Number(shared.budget || 0).toFixed(2), budgetDisplay: amountParts(shared.budget), members: shared.members || this.data.members, tripName: shared.tripName || '暂无行程', ...totalsState(shared.records || [], shared.budget), currentDate: groups.length ? groups[0].date : localDate(), currentDateLabel: groups.length ? groups[0].dateLabel : dateParts(localDate()).label }, () => {
      setTimeout(() => this.measureRecordsPin(), 30)
    })
    if (options && options.invite) this.acceptInvite(options.invite)
  },

  measureRecordsPin(retry = 0) {
    wx.createSelectorQuery()
      .selectViewport().scrollOffset()
      .select('.team-row').boundingClientRect()
      .select('.records-heading').boundingClientRect()
      .exec(result => {
        const scroll = result && result[0]
        const tripRect = result && result[1]
        const headingRect = result && result[2]
        if (!tripRect || !headingRect) {
          if (retry < 10) setTimeout(() => this.measureRecordsPin(retry + 1), 80)
          return
        }
        const scrollTop = Number(scroll && scroll.scrollTop || 0)
        const pinTop = Math.max(0, Math.round(tripRect.top))
        const trigger = Math.max(0, Math.round(headingRect.top + scrollTop - tripRect.top))
        this._recordsPinTop = pinTop
        this._recordsPinTrigger = trigger
        const recordsPinned = scrollTop >= trigger
        const nextState = {}
        if (this.data.recordsPinnedTop !== pinTop) nextState.recordsPinnedTop = pinTop
        if (this.data.recordsPinned !== recordsPinned) nextState.recordsPinned = recordsPinned
        if (Object.keys(nextState).length) this.setData(nextState)
      })
  },

  onShareAppMessage() {
    const { inviteToken, inviteTripId, tripId, tripName } = getApp().globalData
    const activeToken = inviteTripId === tripId ? inviteToken : ''
    return { title: `邀请你加入${tripName || '轻游行程'}`, path: `/pages/home/index?invite=${encodeURIComponent(activeToken || '')}` }
  },

  prepareInvite() {
    const app = getApp()
    if (app.globalData.inviteToken && app.globalData.inviteTripId === app.globalData.tripId) return
    app.createInvite()
  },

  onReady() {
    this.measureRecordsPin()
  },

  onPageScroll(event) {
    const navScrolled = Number(event.scrollTop || 0) > 4
    if (navScrolled !== this.data.navScrolled) this.setData({ navScrolled })
    if (typeof this._recordsPinTrigger !== 'number') {
      this.measureRecordsPin()
    } else {
      const recordsPinned = event.scrollTop >= this._recordsPinTrigger
      if (recordsPinned !== this.data.recordsPinned) this.setData({ recordsPinned })
    }
    if (this._scrollTimer || !this.data.groups.length) return
    this._scrollTimer = setTimeout(() => {
      this._scrollTimer = null
      wx.createSelectorQuery().selectAll('.record-card').boundingClientRect(rects => {
        if (!rects || !rects.length) return
        const line = this.data.navHeight + 66
        let index = 0
        rects.forEach((rect, current) => { if (rect.top <= line) index = current })
        const group = this.data.groups[index]
        if (group && group.date !== this.data.currentDate) this.setData({ currentDate: group.date, currentDateLabel: group.dateLabel, dateOpen: false })
      }).exec()
    }, 60)
  },

  acceptInvite(inviteToken) {
    const app = getApp()
    if (!app.globalData.apiBase) return wx.showToast({ title: '需配置协作服务后加入', icon: 'none' })
    app.joinInvite(inviteToken).then(data => {
        if (!data || typeof data !== 'object') return wx.showToast({ title: '邀请已失效', icon: 'none' })
        const tripId = data.tripId || data.id
        const journeys = Array.isArray(app.globalData.journeys) ? [...app.globalData.journeys] : []
        const nextJourney = {
          id: tripId,
          name: data.tripName || data.name || '暂无行程',
          records: Array.isArray(data.records) ? data.records : [],
          budget: Number(data.budget || 0),
          members: Array.isArray(data.members) && data.members.length ? data.members : [{ id: 'me', name: '我', avatarUrl: '/assets/avatar-me.png' }]
        }
        const index = journeys.findIndex(item => item.id === tripId)
        if (index >= 0) journeys[index] = { ...journeys[index], ...nextJourney }
        else journeys.unshift(nextJourney)
        app.globalData.journeys = journeys
        app.globalData.activeTripId = tripId
        // 不用 ...data 盲目展开：接口返回的行程对象可能带分享者私有字段（如全部行程名单 trips），只落白名单字段
        app.saveState({ tripId, tripName: nextJourney.name, records: nextJourney.records, budget: nextJourney.budget, members: nextJourney.members })
        app.switchJourney(tripId)
        const groups = buildGroups(app.globalData.records || [])
        this.setData({ members: app.globalData.members, tripName: app.globalData.tripName, ...totalsState(app.globalData.records, app.globalData.budget), currentDate: groups.length ? groups[0].date : localDate(), currentDateLabel: groups.length ? groups[0].dateLabel : dateParts(localDate()).label }, () => {
          setTimeout(() => this.measureRecordsPin(), 30)
        })
        wx.showToast({ title: '已加入行程', icon: 'success' })
    })
  },

  toggleDate() {
    this.setData({ dateOpen: !this.data.dateOpen })
  },

  jumpToDate(event) {
    const date = event.currentTarget.dataset.date
    const group = this.data.groups.find(item => item.date === date)
    if (!group) return
    this.setData({ dateOpen: false, currentDate: date, currentDateLabel: group.dateLabel })
    wx.pageScrollTo({ selector: `#record-${date}`, offsetTop: -(this.data.navHeight + 62), duration: 320 })
  },

  chooseTab(event) {
    const index = Number(event.currentTarget.dataset.index)
    if (index === 2) {
      this.setData({ pageLeaving: true })
      setTimeout(() => wx.redirectTo({ url: '/pages/stats/index' }), 180)
    }
    else this.setData({ activeTab: index })
  },

  recordTouchStart(event) {
    const touch = event.touches[0]
    this._recordTouch = { x: touch.clientX, y: touch.clientY, moved: false, horizontal: false, vertical: false }
  },

  recordTouchMove(event) {
    if (!this._recordTouch) return
    const touch = event.touches[0]
    const dx = touch.clientX - this._recordTouch.x
    const dy = touch.clientY - this._recordTouch.y
    if (!this._recordTouch.horizontal && !this._recordTouch.vertical) {
      if (Math.abs(dy) > 10 && Math.abs(dy) > Math.abs(dx) * 1.2) this._recordTouch.vertical = true
      else if (Math.abs(dx) > 18 && Math.abs(dx) > Math.abs(dy) * 1.45) this._recordTouch.horizontal = true
    }
    if (this._recordTouch.horizontal) this._recordTouch.moved = true
  },

  recordTouchEnd(event) {
    if (!this._recordTouch) return
    const touch = event.changedTouches[0]
    const dx = touch.clientX - this._recordTouch.x
    const id = event.currentTarget.dataset.id
    this._lastGestureMoved = this._recordTouch.moved
    if (this._recordTouch.horizontal && dx < -58) this.setData({ swipedRecordId: id })
    else if (this._recordTouch.horizontal && dx > 38) this.setData({ swipedRecordId: '' })
    this._recordTouch = null
  },

  editRecord(event) {
    if (this._lastGestureMoved) {
      this._lastGestureMoved = false
      return
    }
    const id = event.currentTarget.dataset.id
    if (this.data.swipedRecordId === id) return this.setData({ swipedRecordId: '' })
    const record = this.data.records.find(item => item.id === id)
    if (!record) return
    this.setData({ editingRecord: record, sheetMode: 'record', sheetVisible: true, swipedRecordId: '' })
  },

  deleteRecord(event) {
    const id = event.currentTarget.dataset.id
    const records = this.data.records.filter(item => item.id !== id)
    const groups = buildGroups(records)
    getApp().saveState({ records })
    getApp().pushTrip()
    this.setData({ ...totalsState(records, this.data.budget), swipedRecordId: '', currentDate: groups.length ? groups[0].date : localDate(), currentDateLabel: groups.length ? groups[0].dateLabel : dateParts(localDate()).label })
  },

  addRecord() {
    const app = getApp()
    app.getUserProfile().then(() => {
      this.setData({ editingRecord: null, sheetMode: 'record', members: app.globalData.members, ...totalsState(app.globalData.records || [], app.globalData.budget), sheetVisible: true })
    })
  },

  // 行程成员区自己的头像：点击直接拉起微信原生头像选择面板（用微信头像/相册/拍照），选完立即上传生效
  onOwnAvatarChoose(event) {
    const temp = event.detail && event.detail.avatarUrl
    if (!temp) return
    const app = getApp()
    wx.showLoading({ title: '更新头像中', mask: true })
    app.uploadAvatar(temp)
      .then(url => app.updateProfile({ name: app.globalData.userName || '微信用户', avatarUrl: url }))
      .then(() => {
        wx.hideLoading()
        app.saveState({ profilePrompted: true })
        this.setData({ avatarHintVisible: false, userAvatarUrl: app.globalData.userAvatarUrl, members: app.globalData.members })
      })
      .catch(error => {
        wx.hideLoading()
        wx.showToast({ title: error.message || '头像保存失败', icon: 'none' })
      })
  },

  dismissAvatarHint() {
    getApp().saveState({ profilePrompted: true })
    this.setData({ avatarHintVisible: false })
  },

  closeSheet() {
    this.setData({ sheetVisible: false, editingRecord: null })
  },

  confirmSheet(event) {
    const value = event.detail
    if (value.mode === 'budget') {
      const remaining = Number(value.amount) - Number(this.data.total)
      getApp().saveState({ budget: Number(value.amount) })
      getApp().pushTrip()
      this.setData({ budget: value.amount, budgetDisplay: amountParts(value.amount), remaining: remaining.toFixed(2), remainingDisplay: amountParts(remaining), sheetVisible: false })
      return
    }
    const record = { id: value.id || `record-${Date.now()}`, categoryId: value.category.id, categoryName: value.category.name, iconUrl: value.category.iconUrl, title: value.name, note: value.note, user: value.payer, date: value.date, time: value.time, value: Number(value.amount), amountDisplay: amountParts(value.amount) }
    const records = value.id ? this.data.records.map(item => item.id === value.id ? record : item) : [record, ...this.data.records]
    const total = records.reduce((sum, item) => sum + Number(item.value || 0), 0)
    const remaining = Number(this.data.budget) - total
    const groups = buildGroups(records)
    getApp().saveState({ records })
    getApp().pushTrip()
    this.setData({
      records, groups, sheetVisible: false, editingRecord: null,
      total: total.toFixed(2),
      totalDisplay: amountParts(total),
      groupTotal: total.toFixed(2),
      remaining: remaining.toFixed(2),
      remainingDisplay: amountParts(remaining),
      average: total.toFixed(2),
      averageDisplay: amountParts(total),
      currentDate: groups.length ? groups[0].date : localDate(),
      currentDateLabel: groups.length ? groups[0].dateLabel : dateParts(localDate()).label
    })
  }
})
