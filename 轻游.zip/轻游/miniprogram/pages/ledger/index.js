const iconMap = {
  dessert: '/assets/dessert.png',
  snack: '/assets/snack.png',
  drink: '/assets/drink.png'
}

const fallbackCategories = Array.from({ length: 24 }, (_, index) => ({
  id: `local-${index + 1}`,
  name: ['餐饮', '购物', '日用', '交通', '住宿', '娱乐', '医疗', '景点'][index % 8],
  iconUrl: iconMap[['dessert', 'snack', 'drink', 'snack'][index % 4]],
  groupId: index < 12 ? 'long-distance' : 'local-traffic',
  groupName: index < 12 ? '大交通' : '当地交通',
  sort: index,
  enabled: true
}))

function normalizeCategories(list) {
  return list
    .filter(item => item && item.enabled !== false)
    .map((item, index) => ({
      id: String(item.id || `category-${index}`),
      name: item.name || '未命名',
      iconUrl: item.iconUrl || item.icon || iconMap.dessert,
      groupId: String(item.groupId || 'other'),
      groupName: item.groupName || '其他分类',
      sort: Number(item.sort || 0)
    }))
    .sort((a, b) => a.sort - b.sort)
}

function buildGroups(categories) {
  const groups = []
  categories.forEach(category => {
    let group = groups.find(item => item.id === category.groupId)
    if (!group) {
      group = { id: category.groupId, name: category.groupName, items: [] }
      groups.push(group)
    }
    group.items.push(category)
  })
  return groups
}

Page({
  data: {
    mode: 'record', amount: '', tripName: '', payer: '小明', note: '', selectedId: '',
    allCategories: [], categories: [], moreGroups: [], moreOpen: false,
    payers: ['小明', '张三三', '李四'], payerIndex: 0
  },
  onLoad(options) {
    this.setData({ mode: options.mode || 'record' })
    this.applyCategories(fallbackCategories)
    this.loadCategories()
  },
  loadCategories() {
    const apiBase = getApp().globalData.apiBase
    if (!apiBase) return
    wx.request({
      url: `${apiBase}/categories`,
      data: { scene: 'expense' },
      success: response => {
        const list = Array.isArray(response.data) ? response.data : response.data && response.data.list
        if (Array.isArray(list) && list.length) this.applyCategories(list)
      }
    })
  },
  applyCategories(source) {
    const allCategories = normalizeCategories(source)
    const firstPage = allCategories.slice(0, 7)
    const categories = [...firstPage, { id: 'more', name: '更多', iconUrl: iconMap.snack, more: true }]
    this.setData({
      allCategories,
      categories,
      moreGroups: buildGroups(allCategories),
      selectedId: this.data.selectedId || (firstPage[0] && firstPage[0].id) || ''
    })
  },
  inputAmount(e) { this.setData({ amount: e.detail.value }) },
  inputTrip(e) { this.setData({ tripName: e.detail.value }) },
  inputNote(e) { this.setData({ note: e.detail.value }) },
  choosePayer(e) { this.setData({ payerIndex: Number(e.detail.value), payer: this.data.payers[Number(e.detail.value)] }) },
  chooseCategory(e) {
    const id = e.currentTarget.dataset.id
    if (id === 'more') this.setData({ moreOpen: true })
    else this.setData({ selectedId: id })
  },
  chooseMore(e) {
    this.setData({ selectedId: e.currentTarget.dataset.id, moreOpen: false })
  },
  closeMore() { this.setData({ moreOpen: false }) },
  cancel() { wx.navigateBack() },
  confirm() {
    if (this.data.mode === 'trip') {
      if (!this.data.tripName.trim()) return wx.showToast({ title: '请输入行程名称', icon: 'none' })
      wx.setStorageSync('newTripName', this.data.tripName.trim())
    } else if (this.data.mode === 'budget') {
      if (!this.data.amount) return wx.showToast({ title: '请输入金额', icon: 'none' })
      wx.setStorageSync('tripBudget', Number(this.data.amount).toFixed(2))
    } else {
      if (!this.data.amount) return wx.showToast({ title: '请输入金额', icon: 'none' })
      const category = this.data.allCategories.find(item => item.id === this.data.selectedId) || this.data.allCategories[0]
      wx.setStorageSync('pendingRecord', { amount: Number(this.data.amount).toFixed(2), payer: this.data.payer, category: category.name, iconUrl: category.iconUrl, note: this.data.note })
    }
    wx.navigateBack()
  }
})
