const STORAGE_KEY = 'qingyou_state_v1'

const uniqueId = prefix => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
function defaultState() {
  return {
    records: [], budget: 0, trips: [], tripName: '暂无行程', tripId: uniqueId('trip'),
    members: [{ id: 'me', name: '我', avatarUrl: '/assets/avatar-me.png' }],
    journeys: [], activeTripId: '', userName: '', userAvatarUrl: '', deviceKey: uniqueId('device'),
    memberId: '', backendToken: '', backendUser: null, inviteToken: '', inviteTripId: '', profilePrompted: false
  }
}
const me = () => ({ id: 'me', name: '我', avatarUrl: '/assets/avatar-me.png' })

App({
  globalData: {
    // 正式发布时改为已配置到微信公众平台的 HTTPS 域名。
    apiBase: 'https://api.yycs.cloud',
    ...defaultState()
  },
  onLaunch() {
    // 拼接处都是 `${apiBase}/xxx`，统一去掉尾部斜杠，避免请求出现双斜杠打到静态页。
    this.globalData.apiBase = String(this.globalData.apiBase || '').replace(/\/+$/, '')
    const saved = wx.getStorageSync(STORAGE_KEY)
    if (saved && typeof saved === 'object') Object.assign(this.globalData, defaultState(), saved)
    if (!this.globalData.deviceKey) this.globalData.deviceKey = uniqueId('device')
    this.migrateJourneys()
    this.applyActiveJourney()
    this.saveState()
    this.authReady = this.loginBackend().then(user => user ? this.pushTrip() : false).catch(() => false)
  },
  migrateJourneys() {
    if (Array.isArray(this.globalData.journeys) && this.globalData.journeys.length) return
    const names = [...new Set([this.globalData.tripName, ...(this.globalData.trips || [])].filter(name => name && name !== '暂无行程'))]
    if (!names.length) names.push('暂无行程')
    this.globalData.journeys = names.map((name, index) => ({
      id: index === 0 ? (this.globalData.tripId || uniqueId('trip')) : uniqueId('trip'), name,
      records: index === 0 ? (this.globalData.records || []) : [],
      budget: index === 0 ? Number(this.globalData.budget || 0) : 0,
      members: index === 0 ? (this.globalData.members || [me()]) : [me()]
    }))
    this.globalData.activeTripId = this.globalData.journeys[0].id
  },
  activeJourney() {
    return this.globalData.journeys.find(item => item.id === this.globalData.activeTripId) || this.globalData.journeys[0]
  },
  applyActiveJourney() {
    const journey = this.activeJourney()
    if (!journey) return
    Object.assign(this.globalData, {
      activeTripId: journey.id, tripId: journey.id, tripName: journey.name,
      records: journey.records || [], budget: Number(journey.budget || 0), members: journey.members || [me()],
      trips: this.globalData.journeys.map(item => item.name)
    })
  },
  switchJourney(id) {
    if (!this.globalData.journeys.some(item => item.id === id)) return null
    this.globalData.activeTripId = id
    this.globalData.inviteToken = ''
    this.globalData.inviteTripId = ''
    this.applyActiveJourney()
    this.saveState()
    this.pushTrip()
    return this.activeJourney()
  },
  createJourney(name) {
    const current = this.globalData.backendUser || me()
    const journey = { id: uniqueId('trip'), name, records: [], budget: 0, members: [current] }
    this.globalData.journeys.unshift(journey)
    this.globalData.activeTripId = journey.id
    this.globalData.inviteToken = ''
    this.globalData.inviteTripId = ''
    this.applyActiveJourney()
    this.saveState()
    this.pushTrip()
    return journey
  },
  renameJourney(id, name) {
    const journey = this.globalData.journeys.find(item => item.id === id)
    if (!journey) return null
    journey.name = name
    this.applyActiveJourney()
    this.saveState()
    this.pushTrip()
    return journey
  },
  deleteJourney(id) {
    const journeys = this.globalData.journeys
    const index = journeys.findIndex(item => item.id === id)
    if (index < 0 || journeys.length <= 1) return null
    const removedActive = this.globalData.activeTripId === id
    journeys.splice(index, 1)
    if (removedActive) {
      this.globalData.activeTripId = journeys[0].id
      this.globalData.inviteToken = ''
      this.globalData.inviteTripId = ''
      this.applyActiveJourney()
    }
    this.saveState()
    if (removedActive) this.pushTrip()
    // 同步删除云端行程，避免后端/管理后台残留已删数据（仅创建者有权删；失败静默，不影响本地）
    const { apiBase } = this.globalData
    if (apiBase) this.request({ url: `${apiBase}/trips/${encodeURIComponent(id)}`, method: 'DELETE' }).catch(() => {})
    return { removedActive }
  },
  saveState(patch = {}) {
    Object.assign(this.globalData, patch)
    const journey = this.activeJourney()
    if (journey) {
      if ('records' in patch) journey.records = patch.records
      if ('budget' in patch) journey.budget = Number(patch.budget || 0)
      if ('members' in patch) journey.members = patch.members
      if ('tripName' in patch) journey.name = patch.tripName
      this.applyActiveJourney()
    }
    const { records, budget, trips, tripName, tripId, members, journeys, activeTripId, userName, userAvatarUrl, deviceKey, memberId, backendToken, backendUser, profilePrompted } = this.globalData
    wx.setStorageSync(STORAGE_KEY, { records, budget, trips, tripName, tripId, members, journeys, activeTripId, userName, userAvatarUrl, deviceKey, memberId, backendToken, backendUser, profilePrompted })
  },
  loginBackend() {
    const { apiBase, deviceKey, userName } = this.globalData
    if (!apiBase) return Promise.resolve(null)
    return new Promise(resolve => wx.login({
      success: login => wx.request({
        url: `${apiBase}/auth/login`, method: 'POST',
        data: { code: login.code, devKey: deviceKey, profile: { name: userName || '微信用户', avatarUrl: this.globalData.userAvatarUrl || '/assets/avatar-me.png' } },
        success: response => {
          const data = response.data || {}
          if (!data.token || !data.user) return resolve(null)
          // 本地还是默认资料、而服务端已有真实昵称（在其他设备填写过）时回填，实现跨设备同步；本地真实资料优先，方向不可逆。
          const serverName = String(data.user.name || '').trim()
          if ((!this.globalData.userName || this.globalData.userName === '微信用户') && serverName && serverName !== '微信用户') {
            this.globalData.userName = serverName
            if (data.user.avatarUrl && data.user.avatarUrl !== '/assets/avatar-me.png') this.globalData.userAvatarUrl = data.user.avatarUrl
          }
          const oldIds = new Set(['me', this.globalData.memberId].filter(Boolean))
          this.globalData.backendToken = data.token
          this.globalData.backendUser = data.user
          this.globalData.memberId = data.user.id
          const members = (this.globalData.members || []).map(item => oldIds.has(item.id) ? { ...data.user } : item)
          if (!members.some(item => item.id === data.user.id)) members.unshift(data.user)
          this.saveState({ members })
          resolve(data.user)
        },
        fail: () => resolve(null)
      }),
      fail: () => resolve(null)
    }))
  },
  request(options) {
    const run = () => new Promise(resolve => wx.request({
      ...options,
      header: { ...(options.header || {}), Authorization: `Bearer ${this.globalData.backendToken}` },
      success: response => resolve(response),
      fail: error => resolve({ statusCode: 0, error })
    }))
    return (this.globalData.backendToken ? Promise.resolve() : (this.authReady || this.loginBackend())).then(run)
  },
  getUserProfile() {
    // wx.getUserProfile 自 2022-10 起被微信收回，仅返回匿名“微信用户”，
    // 头像改由首页成员区头像（chooseAvatar 微信原生面板）采集；昵称不再采集。
    return Promise.resolve(this.globalData.userName || '')
  },
  uploadAvatar(filePath) {
    const base = this.globalData.apiBase
    if (!base) return Promise.reject(new Error('未配置服务地址'))
    const extMatch = /\.([a-zA-Z0-9]+)$/.exec(filePath || '')
    const ext = (extMatch ? extMatch[1] : 'jpg').toLowerCase()
    const mime = ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg'
    return new Promise((resolve, reject) => {
      wx.getFileSystemManager().readFile({
        filePath, encoding: 'base64',
        success: read => this.request({
          url: `${base}/upload`, method: 'POST',
          data: { dataUrl: `data:${mime};base64,${read.data}` }
        }).then(response => {
          const url = response.statusCode === 201 && response.data && response.data.url
          if (!url) return reject(new Error(response.data && response.data.message || '头像上传失败'))
          resolve(/^https?:/.test(url) ? url : base + url)
        }),
        fail: () => reject(new Error('读取头像失败'))
      })
    })
  },
  updateProfile({ name, avatarUrl }) {
    this.globalData.userName = name
    if (avatarUrl) this.globalData.userAvatarUrl = avatarUrl
    const myId = this.globalData.memberId
    const members = (this.globalData.members || []).map(member => (member.id === 'me' || member.id === myId)
      ? { ...member, name, avatarUrl: avatarUrl || member.avatarUrl }
      : member)
    this.saveState({ members })
    // 重新登录让后端 upsert 最新资料（好友拉取行程时成员列表来自 auth.users）
    return this.loginBackend().then(() => {
      this.pushTrip()
      return this.globalData.members
    })
  },
  syncTrip() {
    const { apiBase, tripId } = this.globalData
    if (!apiBase || !tripId) return Promise.resolve(null)
    return this.request({ url: `${apiBase}/trips/${tripId}` }).then(response => {
      if (response.statusCode !== 200) return null
      const data = response.data && (response.data.data || response.data)
      if (data && typeof data === 'object') this.saveState({ records: data.records || [], budget: data.budget, members: data.members || [], tripName: data.tripName })
      return data || null
    })
  },
  pushTrip() {
    const { apiBase, tripId, records, budget, tripName } = this.globalData
    if (!apiBase || !tripId) return Promise.resolve(false)
    // 只上传本行程数据；不上传 globalData.trips（那是自己全部行程的名单，随行程分享会泄露给成员）
    return this.request({ url: `${apiBase}/trips/${tripId}`, method: 'PUT', data: { records, budget, tripName } }).then(response => {
      const data = response.data && response.data.data
      if (response.statusCode === 200 && data) this.saveState({ members: data.members || this.globalData.members })
      return response.statusCode === 200
    })
  },
  createInvite() {
    const { apiBase, tripId } = this.globalData
    if (!apiBase || !tripId) return Promise.resolve('')
    return this.pushTrip().then(() => this.request({ url: `${apiBase}/trips/${tripId}/invites`, method: 'POST' })).then(response => {
      const inviteToken = response.statusCode === 201 && response.data && response.data.token || ''
      this.globalData.inviteToken = inviteToken
      this.globalData.inviteTripId = inviteToken ? tripId : ''
      return inviteToken
    })
  },
  joinInvite(inviteToken) {
    const { apiBase } = this.globalData
    if (!apiBase || !inviteToken) return Promise.resolve(null)
    return this.request({ url: `${apiBase}/invites/${encodeURIComponent(inviteToken)}/join`, method: 'POST' }).then(response => {
      if (response.statusCode !== 200) return null
      return response.data && (response.data.data || response.data)
    })
  }
})
