const icons = ['/assets/dessert.png', '/assets/snack.png', '/assets/drink.png', '/assets/snack.png']
const names = ['餐饮', '购物', '日用', '交通', '住宿', '娱乐', '医疗', '景点']
const fallback = Array.from({ length: 24 }, (_, index) => ({
  id: `local-${index + 1}`, name: names[index % names.length], iconUrl: icons[index % 4],
  groupId: index < 12 ? 'long' : 'local', groupName: index < 12 ? '大交通' : '当地交通',
  sort: index, enabled: true
}))

function today() {
  const date = new Date()
  const pad = value => String(value).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
}

function currentTime() {
  const date = new Date()
  const pad = value => String(value).padStart(2, '0')
  return `${pad(date.getHours())}:${pad(date.getMinutes())}`
}

function normalize(list) {
  return list.filter(item => item && item.enabled !== false).map((item, index) => ({
    id: String(item.id || `category-${index}`), name: item.name || '未命名',
    iconUrl: item.iconUrl || item.icon || icons[0], groupId: String(item.groupId || 'other'),
    groupName: item.groupName || '其他分类', sort: Number(item.sort || 0)
  })).sort((a, b) => a.sort - b.sort)
}

function groups(list) {
  const result = []
  list.forEach(item => {
    let group = result.find(value => value.id === item.groupId)
    if (!group) { group = { id: item.groupId, name: item.groupName, items: [] }; result.push(group) }
    group.items.push(item)
  })
  return result
}

Component({
  properties: {
    visible: { type: Boolean, value: false, observer: 'visibleChanged' },
    mode: { type: String, value: 'record' },
    initialRecord: { type: Object, value: null, observer: 'initialRecordChanged' },
    members: { type: Array, value: [], observer: 'membersChanged' }
  },
  data: {
    rendered: false, active: false, moreOpen: false, amount: '', expenseName: '', note: '',
    date: today(), payer: '微信用户', payerIndex: 0, payers: ['微信用户'],
    allCategories: [], categories: [], categoryGroups: [], selectedId: '', pendingSelectedId: ''
  },
  lifetimes: {
    attached() { this.applyCategories(fallback); this.loadCategories() }
  },
  methods: {
    visibleChanged(visible) {
      if (visible) {
        this.loadCategories()
        const reset = this.properties.mode === 'record' && !this.properties.initialRecord
          ? { amount: '', expenseName: '', note: '', date: today(), payer: getApp().globalData.userName || '微信用户', payerIndex: 0 }
          : {}
        this.setData({ rendered: true, moreOpen: false, pendingSelectedId: '', ...reset })
        setTimeout(() => this.setData({ active: true }), 20)
      } else if (this.data.rendered) {
        this.setData({ active: false, moreOpen: false })
        setTimeout(() => this.setData({ rendered: false }), 320)
      }
    },
    initialRecordChanged(record) {
      if (!record || !record.id) return
      const payerIndex = Math.max(0, this.data.payers.indexOf(record.user))
      this.setData({
        amount: String(record.value || ''), expenseName: record.title || '', date: record.date || today(),
        payer: record.user || getApp().globalData.userName || '微信用户', payerIndex, note: record.note || '', selectedId: record.categoryId || this.data.selectedId
      })
    },
    membersChanged(members) {
      const names = (members || []).map(item => {
        if (typeof item === 'string') return item === '我' ? (getApp().globalData.userName || '微信用户') : item
        return item && item.id === 'me' && getApp().globalData.userName ? getApp().globalData.userName : item && item.name
      }).filter(Boolean)
      const list = names.length ? names : [getApp().globalData.userName || '微信用户']
      const current = list.includes(this.data.payer) ? this.data.payer : list[0]
      this.setData({ payers: list, payer: current, payerIndex: Math.max(0, list.indexOf(current)) })
    },
    loadCategories() {
      const base = getApp().globalData.apiBase
      if (!base) return
      wx.request({ url: `${base}/categories`, data: { scene: 'expense' }, success: response => {
        const list = Array.isArray(response.data) ? response.data : response.data && response.data.list
        if (Array.isArray(list) && list.length) this.applyCategories(list)
      } })
    },
    applyCategories(source) {
      const version = Date.now()
      const allCategories = normalize(source).map(item => ({
        ...item,
        iconUrl: /^https?:\/\//.test(item.iconUrl)
          ? `${item.iconUrl}${item.iconUrl.includes('?') ? '&' : '?'}v=${version}`
          : item.iconUrl
      }))
      const first = allCategories.slice(0, 7)
      const selectedId = allCategories.some(item => item.id === this.data.selectedId)
        ? this.data.selectedId
        : (first[0] && first[0].id) || ''
      this.setData({
        allCategories, categoryGroups: groups(allCategories), selectedId,
        categories: [...first, { id: 'more', name: '更多', iconUrl: icons[1] }]
      })
    },
    stop() {},
    requestClose() { this.triggerEvent('close') },
    inputAmount(e) { this.setData({ amount: e.detail.value }) },
    inputExpenseName(e) { this.setData({ expenseName: e.detail.value }) },
    inputNote(e) { this.setData({ note: e.detail.value }) },
    chooseDate(e) { this.setData({ date: e.detail.value }) },
    choosePayer(e) { const i = Number(e.detail.value); this.setData({ payerIndex: i, payer: this.data.payers[i] }) },
    chooseCategory(e) {
      const id = e.currentTarget.dataset.id
      id === 'more' ? this.setData({ moreOpen: true, pendingSelectedId: this.data.selectedId }) : this.setData({ selectedId: id })
    },
    chooseMore(e) { this.setData({ pendingSelectedId: e.currentTarget.dataset.id }) },
    cancelMore() { this.setData({ moreOpen: false, pendingSelectedId: '' }) },
    confirmMore() {
      const selected = this.data.allCategories.find(item => item.id === this.data.pendingSelectedId)
      if (!selected) return this.cancelMore()
      const current = this.data.categories.filter(item => item.id !== 'more')
      const oldFirstId = current[0] && current[0].id
      let rest = current.filter(item => item.id !== selected.id && item.id !== oldFirstId)
      const usedIds = [selected.id, oldFirstId, ...rest.map(item => item.id)]
      const fillers = this.data.allCategories.filter(item => !usedIds.includes(item.id))
      rest = [...rest, ...fillers].slice(0, 6)
      this.setData({
        categories: [selected, ...rest, { id: 'more', name: '更多', iconUrl: icons[1] }],
        selectedId: selected.id,
        pendingSelectedId: '',
        moreOpen: false
      })
    },
    confirm() {
      if (this.properties.mode === 'budget') {
        if (!this.data.amount) return wx.showToast({ title: '请输入金额', icon: 'none' })
        this.triggerEvent('confirm', { mode: 'budget', amount: Number(this.data.amount).toFixed(2) })
      } else {
        if (!this.data.amount) return wx.showToast({ title: '请输入金额', icon: 'none' })
        if (!this.data.expenseName.trim()) return wx.showToast({ title: '请输入消费名称', icon: 'none' })
        const category = this.data.allCategories.find(item => item.id === this.data.selectedId) || this.data.allCategories[0]
        this.triggerEvent('confirm', { mode: 'record', id: this.properties.initialRecord && this.properties.initialRecord.id || '', name: this.data.expenseName.trim(), amount: Number(this.data.amount).toFixed(2), date: this.data.date, time: this.properties.initialRecord && this.properties.initialRecord.time || currentTime(), payer: this.data.payer, note: this.data.note, category })
        this.setData({ amount: '', expenseName: '', note: '', date: today(), payer: getApp().globalData.userName || '微信用户' })
      }
    }
  }
})
