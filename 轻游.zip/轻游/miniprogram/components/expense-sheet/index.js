// 分类与云端完全同步：云端没有就不显示，本地不内置任何兜底分类（icons 仅用于「更多」按钮图标）
const icons = ['/assets/dessert.png', '/assets/snack.png', '/assets/drink.png', '/assets/snack.png']

function today() {
  const date = new Date()
  const pad = value => String(value).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
}

function currentTime() {
  const date = new Date()
  const pad = value => String(value).padStart(2, '0')
  return `${pad(date.getHours())}:${pad(date.getMinutes())}`
}

function normalize(list) {
  return list.filter(item => item && item.enabled !== false).map((item, index) => ({
    id: String(item.id || `category-${index}`), name: item.name || '未命名',
    iconUrl: item.iconUrl || item.icon || icons[0], groupId: String(item.groupId || 'other'),
    groupName: item.groupName || '其他分类', sort: Number(item.sort || 0)
  })).sort((a, b) => a.sort - b.sort)
}

function groups(list) {
  const result = []
  list.forEach(item => {
    let group = result.find(value => value.id === item.groupId)
    if (!group) { group = { id: item.groupId, name: item.groupName, items: [] }; result.push(group) }
    group.items.push(item)
  })
  return result
}

Component({
  properties: {
    visible: { type: Boolean, value: false, observer: 'visibleChanged' },
    mode: { type: String, value: 'record' },
    initialRecord: { type: Object, value: null, observer: 'initialRecordChanged' },
    members: { type: Array, value: [], observer: 'membersChanged' }
  },
  data: {
    rendered: false, active: false, moreOpen: false, amount: '', expenseName: '', note: '',
    date: today(), payer: '微信用户', payerIndex: 0, payers: ['微信用户'], selfPayerIndex: 0,
    nameManuallyEdited: false,
    allCategories: [], categories: [], categoryGroups: [], selectedId: '', pendingSelectedId: ''
  },
  lifetimes: {
    attached() { this.loadCategories() }
  },
  methods: {
    visibleChanged(visible) {
      if (visible) {
        this.loadCategories()
        // 付款人默认选中「当前微信用户自己」在成员列表中的位置；名称默认取当前选中（第一个）分类名
        const selfIndex = this.data.selfPayerIndex || 0
        const selected = this.data.allCategories.find(item => item.id === this.data.selectedId) || this.data.allCategories[0]
        const reset = this.properties.mode === 'record' && !this.properties.initialRecord
          ? { amount: '', expenseName: (selected && selected.name) || '', note: '', date: today(), payer: this.data.payers[selfIndex] || getApp().globalData.userName || '微信用户', payerIndex: selfIndex, nameManuallyEdited: false }
          : {}
        this.setData({ rendered: true, moreOpen: false, pendingSelectedId: '', ...reset })
        setTimeout(() => this.setData({ active: true }), 20)
      } else if (this.data.rendered) {
        this.setData({ active: false, moreOpen: false })
        setTimeout(() => this.setData({ rendered: false }), 320)
      }
    },
    initialRecordChanged(record) {
      if (!record || !record.id) return
      const payerIndex = Math.max(0, this.data.payers.indexOf(record.user))
      // 编辑已有记录：名称是用户数据，切换分类时不自动覆盖
      this.setData({
        amount: String(record.value || ''), expenseName: record.title || '', date: record.date || today(),
        payer: record.user || getApp().globalData.userName || '微信用户', payerIndex, note: record.note || '', selectedId: record.categoryId || this.data.selectedId,
        nameManuallyEdited: true
      })
    },
    membersChanged(members) {
      const app = getApp()
      const memberId = app.globalData.memberId
      const entries = (members || []).map(item => {
        if (typeof item === 'string') return { id: '', name: item === '我' ? (app.globalData.userName || '微信用户') : item }
        if (!item) return null
        return { id: item.id, name: item.id === 'me' && app.globalData.userName ? app.globalData.userName : item.name }
      }).filter(item => item && item.name)
      const list = entries.length ? entries.map(item => item.name) : [app.globalData.userName || '微信用户']
      // 当前微信用户（me / 自己的 memberId）在列表中的位置，作为付款人默认值
      const selfIndex = Math.max(0, entries.findIndex(item => item.id === 'me' || item.id === memberId))
      let index = list.indexOf(this.data.payer)
      if (index < 0) index = selfIndex
      this.setData({ payers: list, payer: list[index] || list[0], payerIndex: Math.max(0, index), selfPayerIndex })
    },
    loadCategories() {
      const base = getApp().globalData.apiBase
      if (!base) return
      wx.request({ url: `${base}/categories`, data: { scene: 'expense' }, success: response => {
        const list = Array.isArray(response.data) ? response.data : response.data && response.data.list
        if (Array.isArray(list)) this.applyCategories(list)
      } })
    },
    applyCategories(source) {
      const version = Date.now()
      const allCategories = normalize(source).map(item => ({
        ...item,
        iconUrl: /^https?:\/\//.test(item.iconUrl)
          ? `${item.iconUrl}${item.iconUrl.includes('?') ? '&' : '?'}v=${version}`
          : item.iconUrl
      }))
      const first = allCategories.slice(0, 7)
      const selectedId = allCategories.some(item => item.id === this.data.selectedId)
        ? this.data.selectedId
        : (first[0] && first[0].id) || ''
      this.setData({
        allCategories, categoryGroups: groups(allCategories), selectedId,
        categories: [...first, { id: 'more', name: '更多', iconUrl: icons[1] }]
      })
      // 分类列表异步加载后默认选中项可能变化，名称未手动改过时跟随新默认分类
      const chosen = allCategories.find(item => item.id === selectedId)
      if (chosen) this.autoFillName(chosen.name)
    },
    stop() {},
    requestClose() { this.triggerEvent('close') },
    inputAmount(e) { this.setData({ amount: e.detail.value }) },
    inputExpenseName(e) { this.setData({ expenseName: e.detail.value, nameManuallyEdited: true }) },
    // 选分类后名称自动跟随分类名；一旦用户手动改过名称就不再覆盖
    autoFillName(name) {
      if (!name || this.data.nameManuallyEdited) return
      this.setData({ expenseName: name })
    },
    inputNote(e) { this.setData({ note: e.detail.value }) },
    chooseDate(e) { this.setData({ date: e.detail.value }) },
    choosePayer(e) { const i = Number(e.detail.value); this.setData({ payerIndex: i, payer: this.data.payers[i] }) },
    chooseCategory(e) {
      const id = e.currentTarget.dataset.id
      if (id === 'more') return this.setData({ moreOpen: true, pendingSelectedId: this.data.selectedId })
      this.setData({ selectedId: id })
      const category = this.data.allCategories.find(item => item.id === id)
      if (category) this.autoFillName(category.name)
    },
    chooseMore(e) { this.setData({ pendingSelectedId: e.currentTarget.dataset.id }) },
    cancelMore() { this.setData({ moreOpen: false, pendingSelectedId: '' }) },
    confirmMore() {
      const selected = this.data.allCategories.find(item => item.id === this.data.pendingSelectedId)
      if (!selected) return this.cancelMore()
      const current = this.data.categories.filter(item => item.id !== 'more')
      const oldFirstId = current[0] && current[0].id
      let rest = current.filter(item => item.id !== selected.id && item.id !== oldFirstId)
      const usedIds = [selected.id, oldFirstId, ...rest.map(item => item.id)]
      const fillers = this.data.allCategories.filter(item => !usedIds.includes(item.id))
      rest = [...rest, ...fillers].slice(0, 6)
      this.setData({
        categories: [selected, ...rest, { id: 'more', name: '更多', iconUrl: icons[1] }],
        selectedId: selected.id,
        pendingSelectedId: '',
        moreOpen: false
      })
      this.autoFillName(selected.name)
    },
    confirm() {
      if (this.properties.mode === 'budget') {
        if (!this.data.amount) return wx.showToast({ title: '请输入金额', icon: 'none' })
        this.triggerEvent('confirm', { mode: 'budget', amount: Number(this.data.amount).toFixed(2) })
      } else {
        if (!this.data.amount) return wx.showToast({ title: '请输入金额', icon: 'none' })
        if (!this.data.expenseName.trim()) return wx.showToast({ title: '请输入消费名称', icon: 'none' })
        const category = this.data.allCategories.find(item => item.id === this.data.selectedId) || this.data.allCategories[0]
        if (!category) return wx.showToast({ title: '暂无可用分类，请先在后台配置', icon: 'none' })
        this.triggerEvent('confirm', { mode: 'record', id: this.properties.initialRecord && this.properties.initialRecord.id || '', name: this.data.expenseName.trim(), amount: Number(this.data.amount).toFixed(2), date: this.data.date, time: this.properties.initialRecord && this.properties.initialRecord.time || currentTime(), payer: this.data.payer, note: this.data.note, category })
        this.setData({ amount: '', expenseName: '', note: '', date: today(), nameManuallyEdited: false })
      }
    }
  }
})
