const pad = value => String(value).padStart(2, '0')

function dateOffset(days, base = new Date()) {
  const date = new Date(base)
  date.setHours(12, 0, 0, 0)
  date.setDate(date.getDate() + days)
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
}

function monthDate(monthOffset, day) {
  const now = new Date()
  const date = new Date(now.getFullYear(), now.getMonth() + monthOffset, day, 12)
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
}

const categories = {
  food: { id: 'local-1', name: '餐饮', iconUrl: '/assets/dessert.png' },
  shopping: { id: 'local-2', name: '购物', iconUrl: '/assets/snack.png' },
  daily: { id: 'local-3', name: '日用', iconUrl: '/assets/drink.png' },
  traffic: { id: 'local-4', name: '交通', iconUrl: '/assets/snack.png' },
  hotel: { id: 'local-5', name: '住宿', iconUrl: '/assets/dessert.png' },
  fun: { id: 'local-6', name: '娱乐', iconUrl: '/assets/snack.png' },
  medical: { id: 'local-7', name: '医疗', iconUrl: '/assets/drink.png' },
  scenic: { id: 'local-8', name: '景点', iconUrl: '/assets/dessert.png' }
}

function record(index, title, value, category, date, time, user, note = '') {
  return {
    id: `test-record-${index}`,
    title,
    value,
    categoryId: category.id,
    categoryName: category.name,
    iconUrl: category.iconUrl,
    date,
    time,
    user,
    note
  }
}

function createTestData() {
  const today = dateOffset(0)
  const records = [
    record(1, '高铁往返票', 1280, categories.traffic, today, '08:20', '我', '二等座往返'),
    record(2, '酒店续住两晚', 2688.8, categories.hotel, today, '09:35', '林小满', '含双人早餐'),
    record(3, '景区联票', 520, categories.scenic, today, '10:10', '周然'),
    record(4, '午餐·本地特色菜', 286.5, categories.food, today, '12:26', '我'),
    record(5, '便利店补给', 48.9, categories.shopping, today, '14:05', '陈屿'),
    record(6, 'KTV包厢与饮料', 688, categories.fun, today, '21:40', '林小满', '四人AA'),

    record(7, '网约车到机场', 136.42, categories.traffic, dateOffset(-1), '06:15', '我'),
    record(8, '机场早餐', 57, categories.food, dateOffset(-1), '07:05', '周然'),
    record(9, '旅行纪念品', 399.99, categories.shopping, dateOffset(-1), '16:32', '陈屿'),
    record(10, '药店买晕车药', 35.6, categories.medical, dateOffset(-1), '18:08', '我'),

    record(11, '海景民宿定金', 12000, categories.hotel, dateOffset(-2), '11:00', '林小满', '测试万元金额缩写'),
    record(12, '包车一日游', 3600, categories.traffic, dateOffset(-2), '17:20', '周然'),
    record(13, '海鲜晚餐', 876.35, categories.food, dateOffset(-2), '19:10', '我'),

    record(14, '全员机票', 52860, categories.traffic, dateOffset(-4), '09:00', '我', '测试5.29万展示'),
    record(15, '旅行摄影服务', 5200, categories.fun, dateOffset(-4), '15:25', '陈屿'),
    record(16, '防晒霜和雨伞', 238, categories.daily, dateOffset(-4), '17:42', '周然'),

    record(17, '超长名称测试：城市夜游观光游船四人套票', 428.76, categories.scenic, dateOffset(-6), '20:30', '林小满', '用于测试标题省略和金额对齐'),
    record(18, '咖啡甜点', 99.5, categories.food, dateOffset(-6), '15:10', '我'),

    record(19, '团队旅行保险', 1688, categories.medical, dateOffset(-9), '10:16', '周然'),
    record(20, '露营装备采购', 4680, categories.shopping, dateOffset(-9), '13:40', '陈屿'),
    record(21, '自驾租车押金', 20000, categories.traffic, dateOffset(-12), '09:30', '我'),
    record(22, '当地停车费', 24, categories.traffic, dateOffset(-12), '18:55', '我'),

    record(23, '月初团建聚餐', 1350, categories.food, monthDate(0, 2), '19:20', '林小满'),
    record(24, '酒店一次性用品', 68.88, categories.daily, monthDate(0, 3), '21:05', '陈屿'),
    record(25, '博物馆讲解服务', 300, categories.scenic, monthDate(0, 5), '11:30', '周然'),

    record(26, '上月酒店尾款', 8650, categories.hotel, monthDate(-1, 26), '10:00', '我'),
    record(27, '上月动车票', 740, categories.traffic, monthDate(-1, 18), '08:10', '林小满'),
    record(28, '上月购物', 1888.18, categories.shopping, monthDate(-1, 12), '16:45', '陈屿'),
    record(29, '上月聚餐', 666, categories.food, monthDate(-1, 8), '18:30', '周然'),

    record(30, '十万元极端金额测试', 123456.78, categories.shopping, monthDate(-2, 15), '12:00', '我', '测试12.35万以及排行榜边界'),
    record(31, '零散公交费', 2, categories.traffic, monthDate(-2, 8), '08:03', '我'),
    record(32, '小额矿泉水', 1.5, categories.daily, monthDate(-3, 20), '13:12', '林小满')
  ]

  return {
    records,
    budget: 50000,
    tripName: '多场景测试行程',
    trips: ['多场景测试行程', '国庆旅行', '周末团建'],
    members: [
      { id: 'me', name: '我', avatarUrl: '/assets/avatar-me.png' },
      { id: 'member-lin', name: '林小满', avatarUrl: '/assets/avatar-me.png' },
      { id: 'member-zhou', name: '周然', avatarUrl: '/assets/avatar-me.png' },
      { id: 'member-chen', name: '陈屿', avatarUrl: '/assets/avatar-me.png' }
    ]
  }
}

module.exports = { createTestData }
