module.exports = {
  apps: [{
    name: 'qingyou-api',
    script: './server.js',
    cwd: __dirname,
    instances: 1,
    autorestart: true,
    max_memory_restart: '512M',
    env: {
      NODE_ENV: 'production',
      PORT: 3100,
      DATA_DIR: './data',
      PUBLIC_BASE_URL: 'https://api.yycs.cloud',
      // ====== 在下面两行的引号内粘贴你的 AppID / AppSecret ======
      // 获取位置：微信公众平台 (mp.weixin.qq.com) → 开发管理 → 开发设置 → 开发者ID
      // AppSecret 如已遗忘可在该页面“重置”后获取（重置后旧 Secret 立即失效）
      WECHAT_APPID: 'wx32785c1e20e5b987',
      WECHAT_SECRET: ''
      // =========================================================
    }
  }]
}
