# 轻游后台部署包

需要 Node.js 16.20 或更高版本，不需要 `npm install`，本项目无第三方依赖。

## 本地启动

```bash
npm start
```

打开 `http://localhost:3100`。

## 轻量云启动

上传整个目录内容，在该目录执行：

```bash
export PORT=3100
export PUBLIC_BASE_URL=https://你的域名
export ADMIN_TOKEN=请设置一个长度较长的后台口令
export WECHAT_APPID=微信小程序AppID
export WECHAT_SECRET=微信小程序AppSecret
npm start
```

推荐使用进程管理器或云平台 Node.js 应用托管，并将域名反向代理到 `127.0.0.1:3100`。

健康检查：`GET /health`。

## 小程序配置

将 `miniprogram/app.js` 的 `apiBase` 改成 HTTPS 后台地址，并在微信公众平台配置：

- request 合法域名：后台域名
- downloadFile 合法域名：后台域名

## 数据与安全

运行数据位于 `data/`：分类、行程和登录会话分别保存在 JSON 文件中。生产环境请定期备份该目录，并迁移到 MySQL/PostgreSQL 以支持多实例部署。

`ADMIN_TOKEN` 设置后，后台管理接口需要请求头 `X-Admin-Token`。小程序公共分类接口不需要后台口令。

正式微信登录依赖 `WECHAT_APPID` 和 `WECHAT_SECRET`。未配置时仅支持本地开发身份，不能作为正式线上登录方案。
