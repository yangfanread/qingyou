const $ = id => document.getElementById(id)
let categories = [], trips = [], editing = null, iconUrl = '', peopleKeyword = ''
let adminToken = localStorage.getItem('qingyou_admin_token') || ''

async function api(url, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) }
  if (url.startsWith('/admin/')) headers['X-Admin-Token'] = adminToken
  const response = await fetch(url, { ...options, headers })
  const data = await response.json()
  if (response.status === 401 && url.startsWith('/admin/')) {
    const next = prompt('请输入后台管理口令', adminToken)
    if (next != null) { adminToken = next.trim(); localStorage.setItem('qingyou_admin_token', adminToken) }
    throw new Error('口令已更新，请重试')
  }
  if (!response.ok) throw new Error(data.message || '请求失败')
  return data
}
function escapeHtml(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]))
}
function toast(text) {
  $('toast').textContent = text
  $('toast').classList.add('show')
  setTimeout(() => $('toast').classList.remove('show'), 1800)
}
async function loadCategories() {
  categories = (await api('/admin/categories')).list
  $('empty').style.display = categories.length ? 'none' : 'block'
  $('list').innerHTML = categories.map((item, index) => `<div class="row"><div class="order"><button data-up="${escapeHtml(item.id)}" ${index === 0 ? 'disabled' : ''}>↑</button><button data-down="${escapeHtml(item.id)}" ${index === categories.length - 1 ? 'disabled' : ''}>↓</button></div><div class="category">${escapeHtml(item.name)}</div><div class="icon-box"><img src="${escapeHtml(item.iconUrl)}"></div><div class="status">启用</div><div class="row-actions"><button data-edit="${escapeHtml(item.id)}">编辑</button><button class="danger" data-delete="${escapeHtml(item.id)}">删除</button></div></div>`).join('')
}
function fmtTime(value) {
  if (!value) return '—'
  const date = new Date(value)
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
}
function memberRowHtml(trip, member) {
  const isOwner = trip.ownerId && trip.ownerId === member.id
  return `<div class="member-row"><img class="member-avatar" src="${escapeHtml(member.avatarUrl || '/assets/avatar-me.png')}"><div class="member-info"><strong>${escapeHtml(member.name || '微信用户')}</strong><span>${escapeHtml(member.id)}</span></div>${isOwner ? '<span class="owner-badge">创建者</span>' : `<button class="danger remove-member" data-trip="${escapeHtml(trip.id)}" data-member="${escapeHtml(member.id)}">移出行程</button>`}</div>`
}
function renderPeople() {
  const keyword = peopleKeyword.trim().toLowerCase()
  const list = keyword ? trips.filter(trip => String(trip.tripName || '').toLowerCase().includes(keyword) || String(trip.id).toLowerCase().includes(keyword) || (Array.isArray(trip.members) ? trip.members : []).some(member => String(member.name || '').toLowerCase().includes(keyword))) : trips
  $('people-empty').style.display = list.length ? 'none' : 'block'
  $('trip-list').innerHTML = list.map(trip => {
    const members = Array.isArray(trip.members) ? trip.members : []
    const avatars = members.slice(0, 6).map(member => `<img class="stack-avatar" src="${escapeHtml(member.avatarUrl || '/assets/avatar-me.png')}" title="${escapeHtml(member.name || '微信用户')}">`).join('')
    const stackLabel = members.length ? (members.length > 6 ? `+${members.length - 6}` : `${members.length} 人`) : '无成员'
    const names = members.slice(0, 3).map(member => escapeHtml(member.name || '微信用户')).join('、')
    const namesLabel = names ? (members.length > 3 ? `${names} 等 ${members.length} 人` : names) : '—'
    const records = Array.isArray(trip.records) ? trip.records.length : 0
    return `<div class="p-row"><div class="p-trip"><strong>${escapeHtml(trip.tripName || '未命名行程')}</strong><span>${escapeHtml(trip.id)}</span></div><div class="p-members"><div class="avatar-stack">${avatars}<span class="stack-more">${stackLabel}</span></div><p>${namesLabel}</p></div><div class="p-count">${records} 笔</div><div class="p-time">${fmtTime(trip.updatedAt)}</div><div class="row-actions"><button data-toggle="${escapeHtml(trip.id)}">成员明细</button><button class="danger" data-delete-trip="${escapeHtml(trip.id)}">删除行程</button></div></div><div class="member-detail" id="detail-${escapeHtml(trip.id)}">${members.map(member => memberRowHtml(trip, member)).join('') || '<div class="member-empty">暂无成员</div>'}</div>`
  }).join('')
}
async function loadPeople() {
  trips = (await api('/admin/trips')).list
  renderPeople()
}
function openCategory(item = null) {
  editing = item
  iconUrl = item && item.iconUrl || ''
  $('modal-title').textContent = item ? '编辑分类' : '新增分类'
  $('name').value = item && item.name || ''
  $('sort').value = item && item.sort || ((categories.length + 1) * 10)
  $('preview').src = iconUrl
  $('modal').classList.add('show')
}
function closeCategory() {
  $('modal').classList.remove('show')
  $('file').value = ''
}

document.querySelector('.admin-nav').onclick = event => {
  const view = event.target.dataset.view
  if (!view) return
  document.querySelectorAll('.nav-tab').forEach(node => node.classList.toggle('active', node.dataset.view === view))
  document.querySelectorAll('.admin-view').forEach(node => node.classList.toggle('active', node.id === `${view}-view`))
  if (view === 'people') loadPeople().catch(error => toast(error.message))
}
$('add').onclick = () => openCategory()
$('cancel').onclick = closeCategory
$('modal').onclick = event => { if (event.target === $('modal')) closeCategory() }
$('refresh-people').onclick = () => loadPeople().then(() => toast('已刷新')).catch(error => toast(error.message))
$('people-search').oninput = event => { peopleKeyword = event.target.value; renderPeople() }
$('file').onchange = async event => {
  const file = event.target.files[0]
  if (!file) return
  const dataUrl = await new Promise(resolve => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.readAsDataURL(file) })
  const result = await api('/admin/upload', { method: 'POST', body: JSON.stringify({ dataUrl }) })
  iconUrl = result.iconUrl
  $('preview').src = iconUrl
}
$('save').onclick = async () => {
  try {
    const value = { name: $('name').value.trim(), iconUrl, sort: Number($('sort').value) }
    if (!value.name || !value.iconUrl) return toast('请填写名称并上传图片')
    if (editing) await api(`/admin/categories/${editing.id}`, { method: 'PUT', body: JSON.stringify(value) })
    else await api('/admin/categories', { method: 'POST', body: JSON.stringify(value) })
    closeCategory(); await loadCategories(); toast('保存成功')
  } catch (error) { toast(error.message) }
}
$('list').onclick = async event => {
  const { edit, delete: remove, up, down } = event.target.dataset
  if (edit) return openCategory(categories.find(item => item.id === edit))
  if (remove) {
    if (!confirm('确定删除这个分类？')) return
    await api(`/admin/categories/${remove}`, { method: 'DELETE' }); await loadCategories(); return toast('已删除')
  }
  const id = up || down
  if (!id) return
  const index = categories.findIndex(item => item.id === id), target = up ? index - 1 : index + 1
  ;[categories[index], categories[target]] = [categories[target], categories[index]]
  await api('/admin/categories/reorder', { method: 'POST', body: JSON.stringify({ ids: categories.map(item => item.id) }) })
  await loadCategories()
}
$('trip-list').onclick = async event => {
  const target = event.target
  const tripId = target.dataset.trip, memberId = target.dataset.member
  if (tripId && memberId) {
    if (!confirm('确定将该成员移出行程？')) return
    try {
      await api(`/admin/trips/${encodeURIComponent(tripId)}/members/${encodeURIComponent(memberId)}`, { method: 'DELETE' })
      await loadPeople(); toast('成员已移出')
    } catch (error) { toast(error.message) }
    return
  }
  const toggle = target.dataset.toggle
  if (toggle) {
    const detail = document.getElementById('detail-' + toggle)
    if (!detail) return
    detail.classList.toggle('open')
    target.textContent = detail.classList.contains('open') ? '收起明细' : '成员明细'
    return
  }
  const deleteTrip = target.dataset.deleteTrip
  if (deleteTrip) {
    if (!confirm('确定删除该行程？删除后成员小程序里的这条共享行程将失效，且不可恢复。')) return
    try {
      await api(`/admin/trips/${encodeURIComponent(deleteTrip)}`, { method: 'DELETE' })
      await loadPeople(); toast('行程已删除')
    } catch (error) { toast(error.message) }
  }
}

loadCategories().catch(error => toast(error.message))
