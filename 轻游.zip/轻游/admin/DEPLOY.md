# 轻量云部署步骤

1. 安装 Node.js 16.20+，将压缩包解压到例如 `/opt/qingyou-api`。
2. 进入目录，无需安装依赖，运行 `npm run check`。
3. 配置 `PUBLIC_BASE_URL`、`ADMIN_TOKEN`、`WECHAT_APPID`、`WECHAT_SECRET`。
4. 用 PM2 启动：`pm2 start ecosystem.config.cjs`，再执行 `pm2 save`。
5. 使用 Nginx/Caddy 将 HTTPS 域名反向代理到 `127.0.0.1:3100`。
6. 访问 `https://你的域名/health`，应返回 `{"ok":true}`。
7. 修改小程序 `apiBase` 为该 HTTPS 域名，并配置微信合法域名。

# 更新部署（每次改代码后）

上传新包**解压覆盖后，只需重启，不要再「启动」**：

```bash
pm2 restart qingyou-api
```

- Node 进程只在启动时读一次代码：覆盖文件不会影响正在跑的旧进程，旧进程会一直占着 3100 端口。
- 此时若再执行 `pm2 start` 或宝塔面板「启动」，等于再开一个新进程抢同一端口，必然报 `EADDRINUSE: address already in use`。
- 用宝塔「Node 项目」面板管理的，覆盖文件后点面板里的「**重启**」按钮，不要「启动」。
- `pm2 list` 检查应始终只有一个实例；多出来的用 `pm2 delete <id>` 清掉。

Nginx 反向代理必须传递：

```nginx
proxy_set_header Host $host;
proxy_set_header X-Forwarded-Proto $host;
proxy_set_header X-Forwarded-Host $host;
```

数据目录 `data/` 和上传目录 `public/uploads/` 必须持久化并定期备份。
