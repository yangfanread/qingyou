# 轻量云部署步骤

1. 安装 Node.js 16.20+，将压缩包解压到例如 `/opt/qingyou-api`。
2. 进入目录，无需安装依赖，运行 `npm run check`。
3. 配置 `PUBLIC_BASE_URL`、`ADMIN_TOKEN`、`WECHAT_APPID`、`WECHAT_SECRET`。
4. 用 PM2 启动：`pm2 start ecosystem.config.cjs`，再执行 `pm2 save`。
5. 使用 Nginx/Caddy 将 HTTPS 域名反向代理到 `127.0.0.1:3100`。
6. 访问 `https://你的域名/health`，应返回 `{"ok":true}`。
7. 修改小程序 `apiBase` 为该 HTTPS 域名，并配置微信合法域名。

Nginx 反向代理必须传递：

```nginx
proxy_set_header Host $host;
proxy_set_header X-Forwarded-Proto $scheme;
proxy_set_header X-Forwarded-Host $host;
```

数据目录 `data/` 和上传目录 `public/uploads/` 必须持久化并定期备份。
